muni_pop <- read.csv("C:/Users/sherl/Miniconda3/envs/vrdi/vrdi_data/week_6/incorporated_place_pop/incorporated_place_pop.csv")
state_master <- read.csv("C:/Users/sherl/Miniconda3/envs/vrdi/vrdi_data/week_6/StateMaster.csv")

states <- c("AL","AK","03","AZ","AR","CA","07","CO","CT","DE",
            "DC","FL","GA","14","HI","ID","IL","IN","IA","KS",
            "KY","LA","ME","MD","MA","MI","MN","MS","MO","MT",
            "NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK",
            "OR","PA","43","RI","SC","SD","TN","TX","UT","VT",
            "VA","52","WA","WV","WI","WY")
state_fips_to_rows <- c(1,2,9999,3,4,5,9999,6,7,8,
                        9,10,11,9999,12,13,14,15,16,17,
                        18,19,20,21,22,23,24,25,26,27,
                        28,29,30,31,32,33,34,35,36,37,
                        38,39,9999,40,41,42,43,44,45,46,
                        47,9999,48,49,50,51)

state <- 56
cd_ca <- NULL
cd_cb <- NULL
sd_ca <- NULL
sd_cb <- NULL
hd_ca <- NULL
hd_cb <- NULL

for (state in 1:state) {
   current_cities <- NULL
   cc_boolean <- NULL
   city <- 19500
   
   for(city in 1: city){
      check_state <- floor(muni_pop[city,2] / (10^5))
      if(check_state == state) {
         cc_boolean <- c(cc_boolean, TRUE)
      } else {
         cc_boolean <- c(cc_boolean, FALSE)
      }
      current_cities <- muni_pop[cc_boolean,]
   }
   
   state_row <- state_fips_to_rows[state]
   
   #federal csvs and columns
   cd_up_005 <- 745540.3*1.005 #district average at 100.5%
   cd_down_005 <- 745540.3*0.995 #district average at 99.5%
   ca_bool <- current_cities$respop72017 >= cd_up_005
   cb_bool <- current_cities$respop72017 <= cd_down_005
   cd_cities_above <- current_cities[ca_bool,]
   cd_cities_below <- current_cities[cb_bool,]
   write.csv(cd_cities_above, paste(states[state],'Above_CD','csv',sep = '.'))
   write.csv(cd_cities_below, paste(states[state],'Below_CD','csv',sep = '.'))
   cd_ca <- c(cd_ca, nrow(cd_cities_above))
   cd_cb <- c(cd_cb, nrow(cd_cities_below))
   
   #state senate csvs and columns
   sd_up_005 <- state_master$SDPE[state_row]*1.005 #district average at 100.5%
   sd_down_005 <- state_master$SDPE[state_row]*0.995 #district average at 99.5%
   sa_bool <- current_cities$respop72017 >= sd_up_005
   sb_bool <- current_cities$respop72017 <= sd_down_005
   sd_cities_above <- current_cities[sa_bool,]
   sd_cities_below <- current_cities[sb_bool,]
   write.csv(sd_cities_above, paste(states[state],'Above_SD','csv',sep = '.'))
   write.csv(sd_cities_below, paste(states[state],'Below_SD','csv',sep = '.'))
   sd_ca <- c(sd_ca, nrow(sd_cities_above))
   sd_cb <- c(sd_cb, nrow(sd_cities_below))
   
   #state house csvs and columns
   hd_up_005 <- state_master$HDPE[state_row]*1.005 #district average at 100.5%
   hd_down_005 <- state_master$HDPE[state_row]*0.995 #district average at 99.5%
   ha_bool <- current_cities$respop72017 >= hd_up_005
   hb_bool <- current_cities$respop72017 <= hd_down_005
   hd_cities_above <- current_cities[ha_bool,]
   hd_cities_below <- current_cities[hb_bool,]
   write.csv(hd_cities_above, paste(states[state],'Above_HD','csv',sep = '.'))
   write.csv(hd_cities_below, paste(states[state],'Below_HD','csv',sep = '.'))
   hd_ca <- c(hd_ca, nrow(hd_cities_above))
   hd_cb <- c(hd_cb, nrow(hd_cities_below))
}
total_cities_count <- data.frame(states, cd_ca, cd_cb, sd_ca, sd_cb, hd_ca, hd_cb)
write.csv(total_cities_count, "cities_count.csv")